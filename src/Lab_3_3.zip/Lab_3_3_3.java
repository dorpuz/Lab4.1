public class Lab_3_3_3 {
    public static void main(String[] args) {
        long[] array = new long[Integer.MAX_VALUE];
    }
}
